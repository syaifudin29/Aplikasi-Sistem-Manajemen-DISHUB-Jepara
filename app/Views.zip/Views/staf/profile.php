<?= $this->extend('staf/template');
	$this->section('content_staf');
?>

<?php $this->endSection(); ?>